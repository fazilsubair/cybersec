Logservice
===============
A service that helps in logs correlation and much more other tasks. It uses Apache Thrift technology to build RPC clients and servers that communicate seamlessly across programming languages.

### Features
* Parse logs  


### Todo
* Support file uploads
* Expose remote services support more clients across network
* Support serialization
* Implement network security & RBAC
