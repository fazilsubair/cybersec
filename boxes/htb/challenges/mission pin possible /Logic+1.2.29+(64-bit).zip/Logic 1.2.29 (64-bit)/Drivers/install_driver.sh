#!/bin/sh -x
sudo cp 99-SaleaeLogic.rules /etc/udev/rules.d/99-SaleaeLogic.rules



